import { useState, useEffect, useContext } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { AuthContext } from "../../App";
import { Card, CardContent, CardHeader, CardTitle } from "../ui/card";
import { Button } from "../ui/button";
import { Badge } from "../ui/badge";
import { 
  ArrowLeft, 
  MapPin, 
  Calendar,
  Package,
  FileText,
  Image as ImageIcon,
  Loader2,
  Edit,
  ClipboardCheck,
  Navigation2,
  AlertCircle
} from "lucide-react";
import { projectId } from "../../../../utils/supabase/info";

interface AssetPhoto {
  photo_id?: string;
  url?: string;
  signedUrl?: string;
  file_path?: string;
  file_name?: string;
  name?: string;
  caption?: string;
  source?: string;
  bucket_id?: string;
}

interface Asset {
  id: string;
  asset_ref: string;
  asset_type: string;
  asset_type_name: string;
  description: string;
  condition: string;
  installation_date: string;
  latitude: number;
  longitude: number;
  location: string;
  road_name?: string;
  chainage?: number;
  side?: string;
  photos?: string[];
  photo_objects?: AssetPhoto[];
  notes?: string;
  last_inspection_date?: string;
  ci_score?: number;
  metadata?: Record<string, any>;
  direction?: string;
  road_side?: string;
  road_subsection?: string;
  created_at?: string;
  captured_at?: string;
}

export default function MobileAssetDetailPage() {
  const { assetId } = useParams();
  const navigate = useNavigate();
  const { accessToken } = useContext(AuthContext);
  const [asset, setAsset] = useState<Asset | null>(null);
  const [assetPhotos, setAssetPhotos] = useState<AssetPhoto[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchAssetDetails();
  }, [assetId]);

  const normalisePhotoList = (rawPhotos: any[] = [], rawObjects: any[] = []): AssetPhoto[] => {
    const combined: AssetPhoto[] = [];

    for (const photo of rawObjects || []) {
      const url = photo?.url || photo?.signedUrl;
      if (url) combined.push(photo);
    }

    for (const photo of rawPhotos || []) {
      if (typeof photo === "string" && photo) {
        combined.push({ url: photo, signedUrl: photo, caption: "Asset Photo" });
      } else if (photo?.url || photo?.signedUrl) {
        combined.push(photo);
      }
    }

    const seen = new Set<string>();
    return combined.filter((photo) => {
      const key = photo.url || photo.signedUrl || photo.file_path || photo.file_name || "";
      if (!key || seen.has(key)) return false;
      seen.add(key);
      return true;
    });
  };

  const fetchResolvedPhotos = async (apiUrl: string) => {
    if (!assetId || !accessToken) return;

    try {
      const response = await fetch(`${apiUrl}/assets/${assetId}/photos`, {
        headers: {
          Authorization: `Bearer ${accessToken}`,
        },
      });

      if (!response.ok) {
        console.warn("Failed to fetch resolved asset photos", await response.text());
        return;
      }

      const data = await response.json();
      const photos = normalisePhotoList(data.photos || [], []);
      setAssetPhotos(photos);
    } catch (error) {
      console.error("Error fetching resolved photos:", error);
    }
  };

  const fetchAssetDetails = async () => {
    const API_URL = `https://${projectId}.supabase.co/functions/v1/make-server-c894a9ff`;

    try {
      const response = await fetch(`${API_URL}/assets/${assetId}`, {
        headers: {
          Authorization: `Bearer ${accessToken}`,
        },
      });

      if (response.ok) {
        const data = await response.json();
        const nextAsset = data.asset;
        setAsset(nextAsset);
        setAssetPhotos(normalisePhotoList([...(nextAsset?.photos || []), ...((nextAsset?.metadata?.photo_urls || []) as any[])], nextAsset?.photo_objects || []));
        await fetchResolvedPhotos(API_URL);
      } else {
        console.error("Failed to fetch asset details");
      }
    } catch (error) {
      console.error("Error fetching asset:", error);
    } finally {
      setLoading(false);
    }
  };

  const getConditionColor = (condition: string) => {
    switch (condition?.toLowerCase()) {
      case "excellent":
        return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200";
      case "good":
        return "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200";
      case "fair":
        return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200";
      case "poor":
        return "bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-200";
      case "critical":
        return "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200";
      default:
        return "bg-slate-100 text-slate-800 dark:bg-slate-800 dark:text-slate-200";
    }
  };

  const formatDate = (dateString: string) => {
    if (!dateString) return "Not set";
    const date = new Date(dateString);
    return date.toLocaleDateString("en-ZA", { 
      month: "short", 
      day: "numeric", 
      year: "numeric" 
    });
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 dark:bg-slate-900 flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!asset) {
    return (
      <div className="min-h-screen bg-slate-50 dark:bg-slate-900 p-4">
        <div className="text-center py-12">
          <AlertCircle className="w-12 h-12 mx-auto mb-3 text-slate-300" />
          <p className="text-slate-500">Asset not found</p>
          <Button 
            variant="outline" 
            onClick={() => navigate(-1)}
            className="mt-4"
          >
            Go Back
          </Button>
        </div>
      </div>
    );
  }

  const photoItems = assetPhotos.length > 0
    ? assetPhotos
    : normalisePhotoList([...(asset.photos || []), ...((asset.metadata?.photo_urls || []) as any[])], asset.photo_objects || []);

  const metadata = asset.metadata || {};
  const displayValue = (...values: any[]) => {
    const value = values.find((item) => item !== undefined && item !== null && String(item).trim() !== "");
    return value === undefined || value === null || String(value).trim() === "" ? "—" : String(value);
  };

  const displayRoad = displayValue(asset.road_name, metadata.road_name, metadata.road);
  const displayDirection = displayValue(asset.direction, metadata.direction, metadata.orientation);
  const displayRoadSide = displayValue(asset.road_side, metadata.road_side, asset.side);
  const displaySubsection = displayValue(asset.road_subsection, metadata.road_subsection);
  const displayDescription = displayValue(asset.description, metadata.description);
  const displayCondition = displayValue(asset.condition, metadata.condition);
  const displayCapturedAt = displayValue(asset.created_at, asset.captured_at, metadata.captured_at);

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-900 pb-20">
      {/* Fixed Header */}
      <div className="sticky top-0 z-20 bg-white dark:bg-slate-800 border-b shadow-sm">
        <div className="flex items-center justify-between p-4">
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => navigate(-1)}
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div>
              <h1 className="text-lg font-bold">{asset.asset_ref}</h1>
              <p className="text-xs text-slate-500">{asset.asset_type_name}</p>
            </div>
          </div>
          <Badge className={getConditionColor(asset.condition)}>
            {asset.condition}
          </Badge>
        </div>
      </div>

      <div className="p-4 space-y-4">
        {/* Photos */}
        {photoItems.length > 0 && (
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center gap-2">
                <ImageIcon className="w-4 h-4" />
                Photos ({photoItems.length})
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 gap-2">
                {photoItems.map((photo, index) => {
                  const src = photo.url || photo.signedUrl || "";
                  return (
                    <div key={`${photo.file_path || src || index}`} className="space-y-1">
                      <img
                        src={src}
                        alt={photo.caption || `Asset photo ${index + 1}`}
                        className="w-full h-24 object-contain rounded-md border bg-slate-100"
                        loading="lazy"
                        onError={(event) => {
                          event.currentTarget.style.display = "none";
                        }}
                      />
                      {(photo.caption || photo.source) && (
                        <p className="text-[10px] text-slate-500 truncate">
                          {photo.caption || photo.source}
                        </p>
                      )}
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Basic Information */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <FileText className="w-4 h-4" />
              Asset Information
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
              <div>
                <p className="text-xs text-slate-500 mb-1">Asset Ref</p>
                <p className="text-sm font-medium font-mono">{asset.asset_ref}</p>
              </div>

              <div>
                <p className="text-xs text-slate-500 mb-1">Type</p>
                <p className="text-sm font-medium">{displayValue(asset.asset_type_name, asset.asset_type)}</p>
              </div>

              <div>
                <p className="text-xs text-slate-500 mb-1">Condition</p>
                <Badge className={getConditionColor(displayCondition)} variant="outline">
                  {displayCondition}
                </Badge>
              </div>

              <div>
                <p className="text-xs text-slate-500 mb-1">Road</p>
                <p className="text-sm font-medium">{displayRoad}</p>
              </div>

              <div>
                <p className="text-xs text-slate-500 mb-1">Direction</p>
                <p className="text-sm font-medium">{displayDirection}</p>
              </div>

              <div>
                <p className="text-xs text-slate-500 mb-1">Road Side</p>
                <p className="text-sm font-medium">{displayRoadSide}</p>
              </div>

              <div>
                <p className="text-xs text-slate-500 mb-1">Subsection</p>
                <p className="text-sm font-medium">{displaySubsection}</p>
              </div>

              <div>
                <p className="text-xs text-slate-500 mb-1">Photos</p>
                <p className="text-sm font-medium">{photoItems.length}</p>
              </div>

              {asset.ci_score !== undefined && asset.ci_score !== null && (
                <div>
                  <p className="text-xs text-slate-500 mb-1">CI Score</p>
                  <p className="text-sm font-bold text-primary">{asset.ci_score}</p>
                </div>
              )}
            </div>

            {displayDescription !== "—" && (
              <div>
                <p className="text-xs text-slate-500 mb-1">Description</p>
                <p className="text-sm">{displayDescription}</p>
              </div>
            )}

            {displayCapturedAt !== "—" && (
              <div>
                <p className="text-xs text-slate-500 mb-1">Captured / Created</p>
                <div className="flex items-center gap-2">
                  <Calendar className="w-4 h-4 text-slate-400" />
                  <p className="text-sm">{formatDate(displayCapturedAt)}</p>
                </div>
              </div>
            )}

            {asset.last_inspection_date && (
              <div>
                <p className="text-xs text-slate-500 mb-1">Last Inspection</p>
                <div className="flex items-center gap-2">
                  <ClipboardCheck className="w-4 h-4 text-slate-400" />
                  <p className="text-sm">{formatDate(asset.last_inspection_date)}</p>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Location Information */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <MapPin className="w-4 h-4" />
              Location
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {asset.location && (
              <div>
                <p className="text-xs text-slate-500 mb-1">Address</p>
                <p className="text-sm">{asset.location}</p>
              </div>
            )}

            <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
              <div>
                <p className="text-xs text-slate-500 mb-1">Road</p>
                <p className="text-sm font-medium">{displayRoad}</p>
              </div>
              <div>
                <p className="text-xs text-slate-500 mb-1">Direction</p>
                <p className="text-sm font-medium">{displayDirection}</p>
              </div>
              <div>
                <p className="text-xs text-slate-500 mb-1">Road Side</p>
                <p className="text-sm font-medium">{displayRoadSide}</p>
              </div>
              {asset.chainage && (
                <div>
                  <p className="text-xs text-slate-500 mb-1">Chainage</p>
                  <p className="text-sm font-medium">{asset.chainage}km</p>
                </div>
              )}
            </div>

            {asset.latitude && asset.longitude && (
              <div>
                <p className="text-xs text-slate-500 mb-1">Coordinates</p>
                <p className="text-xs font-mono text-slate-600 dark:text-slate-400">
                  {asset.latitude.toFixed(6)}, {asset.longitude.toFixed(6)}
                </p>
                <div className="flex gap-2 mt-2">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => navigate(`/mobile/map?asset=${asset.id}`)}
                    className="gap-2 flex-1"
                  >
                    <MapPin className="w-4 h-4" />
                    View on Map
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => {
                      window.open(
                        `https://www.google.com/maps/dir/?api=1&destination=${asset.latitude},${asset.longitude}`,
                        "_blank"
                      );
                    }}
                    className="gap-2 flex-1"
                  >
                    <Navigation2 className="w-4 h-4" />
                    Navigate
                  </Button>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Notes */}
        {asset.notes && (
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center gap-2">
                <FileText className="w-4 h-4" />
                Notes
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-slate-600 dark:text-slate-400">
                {asset.notes}
              </p>
            </CardContent>
          </Card>
        )}

        {/* Actions */}
        <div className="flex gap-3">
          <Button
            className="flex-1 gap-2"
            onClick={() => navigate(`/mobile/inspections/new?asset=${asset.id || (asset as any).asset_id || asset.asset_ref}`)}
          >
            <ClipboardCheck className="w-4 h-4" />
            New Inspection
          </Button>
        </div>
      </div>
    </div>
  );
}
